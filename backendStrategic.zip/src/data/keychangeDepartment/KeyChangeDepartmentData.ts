/* tslint:disable await-promise */
import {QueryBuilder} from 'knex'

import {DataClient} from '../index'
import {Database} from '../../config'

export interface KeyChangeDepartment {
  id?: string
  department_id?: string
  project_id?: string
}

export interface Data {
  get: ReturnType<typeof get>,
  getAll: ReturnType<typeof getAll>,
  update: ReturnType<typeof update>,
  insert: ReturnType<typeof insert>,
  deleteKeyChangeDepartment: ReturnType<typeof deleteKeyChangeDepartment>,
}

export interface GetInput {
  id?: string
  department_id?: string
  key_change_id?: string
  project_id?: string
}

export const get = (keychangeDepartments: () => QueryBuilder) => async (input: GetInput) => {
  return  keychangeDepartments().select().where(input).first()
}

export const getAll = (stakeholderDepartments: () => QueryBuilder) => async (input: GetInput) => {
  return  stakeholderDepartments().select().where(input)
}

export const insert = (stakeholderDepartments: () => QueryBuilder) => async (input: GetInput) => {
  return  (await stakeholderDepartments().insert(input, ['id']) as [{id: string, name:string}])[0]
}

export const update = (stakeholderDepartments: () => QueryBuilder) => async (input: GetInput) => {
  const { id, ...updateFields } = input;

  if (!id) {
    throw new Error("An ID must be provided to update a key change.");
  }

  return (await stakeholderDepartments().where({ id }).update(updateFields, ['id']) as [{id: string}])[0];
}

export const deleteKeyChangeDepartment = (stakeholderDepartments: () => QueryBuilder) => async (input: GetInput) => {
  const { id } = input;

  if (!id) {
    throw new Error("An ID must be provided to delete a key change.");
  }

  return (await stakeholderDepartments().where({ id }).del() as number);
}

export async function create (data: DataClient): Promise<Data> {
  const keyChangeDepartments = () => data.postgres.withSchema(Database.schema).table('KeyChangeDepartment')

  return {
    get:              get(keyChangeDepartments),
    getAll:           getAll(keyChangeDepartments),
    update:           update(keyChangeDepartments),
    insert:           insert(keyChangeDepartments),
    deleteKeyChangeDepartment:  deleteKeyChangeDepartment(keyChangeDepartments),
  }
}

export default {create}
