import { catchErrors } from '../errors';
import DataProvider from "../data/DataProvider";
import StakeholderHandlers from "../data/stakeholder/StakeholderHandlers";


export const getStakeholders = catchErrors(async (req, res) => {
    const data = await DataProvider.create()
    const stakeholderHandler = await StakeholderHandlers.create(data)

    console.log("Body", req.query)
    const stakeholders = await stakeholderHandler.getAll({})
    res.respond({ data: stakeholders });
});

export const getStakeholder = catchErrors(async (req, res) => {
    const data = await DataProvider.create()
    const stakeholderHandler = await StakeholderHandlers.create(data)

    const id = req.params.id;
    if (!id) {
        res.send("Missing stakeholder id").status(400)
        throw new Error('Missing stakeholder id');
    }

    const stakeholder = await stakeholderHandler.get({ id })

    res.respond({ stakeholder });
});

export const addStakeholder = catchErrors(async (req, res) => {
    const stakeholderData = req.body;


    return res.respond({body: req.body})

    if (!stakeholderData) {
        res.status(400).send("Missing stakeholder data");
        throw new Error('Missing stakeholder data');
    }

    const data = await DataProvider.create();
    const stakeholderHandler = await StakeholderHandlers.create(data);

    const stakeholder = await stakeholderHandler.insert(stakeholderData);
    res.respond({ stakeholder });
})


export const updateStakeholder = catchErrors(async (req, res) => {
    const data = await DataProvider.create()
    const stakeholderHandler = await StakeholderHandlers.create(data)

    const id = req.params.id;
    const updateData = req.body;


    if (!id || !updateData) {
        res.send("Missing stakeholder id or update data").status(400)
        throw new Error('Missing stakeholder id or update data');
    }

    const stakeholder = await stakeholderHandler.update({ ...updateData, id })

    res.respond({ stakeholder });
});

export const deleteStakeholder = catchErrors(async (req, res) => {
    const data = await DataProvider.create()
    const stakeholderHandler = await StakeholderHandlers.create(data)

    const id = req.params.id;
    if (!id) {
        res.send("Missing stakeholder id").status(400)
        throw new Error('Missing stakeholder id');
    }

    await stakeholderHandler.deleteStakeholder({ id })

    res.respond({ message: 'Stakeholder deleted successfully' });
});
