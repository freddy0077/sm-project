export enum CountryIdentifier {
    CCA2 = 'cca2',
    CCA3 = 'cca3'
}
